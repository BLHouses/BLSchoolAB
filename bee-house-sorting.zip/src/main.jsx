import React from 'react';
import ReactDOM from 'react-dom/client';
import BeeHiveSorter from './BeeHiveSorter';
import './index.css';

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <BeeHiveSorter />
  </React.StrictMode>
);
